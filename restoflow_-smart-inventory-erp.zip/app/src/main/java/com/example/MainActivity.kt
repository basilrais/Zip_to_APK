package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModelProvider
import com.example.data.database.AppDatabase
import com.example.data.repository.RestaurantRepository
import com.example.ui.screens.ErpMainScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.RestaurantViewModel
import com.example.ui.viewmodel.RestaurantViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize Room Database & Repository
        val database = AppDatabase.getDatabase(applicationContext)
        val repository = RestaurantRepository(database)
        
        // Instantiate ViewModel using the Custom Factory
        val factory = RestaurantViewModelFactory(application, repository)
        val viewModel = ViewModelProvider(this, factory)[RestaurantViewModel::class.java]

        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                ErpMainScreen(viewModel)
            }
        }
    }
}

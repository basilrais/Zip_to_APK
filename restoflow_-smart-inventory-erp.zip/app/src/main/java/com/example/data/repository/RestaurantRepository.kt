package com.example.data.repository

import com.example.data.database.AppDatabase
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

class RestaurantRepository(private val db: AppDatabase) {

    // DAOs
    val employeeDao = db.employeeDao()
    val ingredientDao = db.ingredientDao()
    val menuItemDao = db.menuItemDao()
    val recipeIngredientDao = db.recipeIngredientDao()
    val saleDao = db.saleDao()
    val saleItemDao = db.saleItemDao()
    val inventoryTransactionDao = db.inventoryTransactionDao()
    val supplierDao = db.supplierDao()
    val purchaseDao = db.purchaseDao()
    val expenseDao = db.expenseDao()
    val notificationDao = db.notificationDao()

    // Flows
    val allEmployees: Flow<List<Employee>> = employeeDao.getAllEmployees()
    val allIngredients: Flow<List<Ingredient>> = ingredientDao.getAllIngredients()
    val allMenuItems: Flow<List<MenuItem>> = menuItemDao.getAllMenuItems()
    val allSales: Flow<List<Sale>> = saleDao.getAllSales()
    val allTransactions: Flow<List<InventoryTransaction>> = inventoryTransactionDao.getAllTransactions()
    val allSuppliers: Flow<List<Supplier>> = supplierDao.getAllSuppliers()
    val allPurchases: Flow<List<Purchase>> = purchaseDao.getAllPurchases()
    val allExpenses: Flow<List<Expense>> = expenseDao.getAllExpenses()
    val allNotifications: Flow<List<AppNotification>> = notificationDao.getAllNotifications()

    // --- Transactions & Advanced Business Logic ---

    /**
     * Records a sale and automatically:
     * 1. Inserts the Sale
     * 2. Inserts all SaleItems
     * 3. Calculates ingredient usage from recipe
     * 4. Deducts quantity from ingredient stock
     * 5. Inserts an InventoryTransaction of type "Sale" for each deduction
     * 6. Triggers a "Low Stock" notification if the stock falls below the minimum
     */
    suspend fun recordSale(sale: Sale, items: List<SaleItem>) = withContext(Dispatchers.IO) {
        // 1. Insert Sale and get generated ID
        val saleId = db.saleDao().insertSale(sale).toInt()

        // 2. Loop through sale items
        for (item in items) {
            val updatedItem = item.copy(saleId = saleId)
            db.saleItemDao().insertSaleItem(updatedItem)

            // 3. Fetch the recipe ingredients for this menu item
            val recipeIngredients = db.recipeIngredientDao().getRecipeIngredientsForMenuItemSync(item.menuItemId)

            // 4. For each ingredient, perform deductions and log transactions
            for (recipeIng in recipeIngredients) {
                val ingredient = db.ingredientDao().getIngredientByIdSync(recipeIng.ingredientId) ?: continue
                
                // Calculate amount consumed
                val quantityConsumed = recipeIng.quantity * item.quantity
                val newStock = (ingredient.currentStock - quantityConsumed).coerceAtLeast(0.0)

                // Update ingredient stock
                db.ingredientDao().updateIngredient(ingredient.copy(currentStock = newStock))

                // 5. Insert Inventory Transaction
                db.inventoryTransactionDao().insertTransaction(
                    InventoryTransaction(
                        ingredientId = ingredient.id,
                        type = "Sale",
                        quantity = -quantityConsumed,
                        cost = ingredient.averageCost * quantityConsumed,
                        date = sale.date,
                        notes = "Sale of ${item.quantity}x Menu Item #${item.menuItemId}"
                    )
                )

                // 6. Check for Low Stock Warning
                if (newStock < ingredient.minStock) {
                    db.notificationDao().insertNotification(
                        AppNotification(
                            type = "Low Stock",
                            title = "Low Stock: ${ingredient.name}",
                            message = "Stock of ${ingredient.name} fell to ${String.format("%.2f", newStock)} ${ingredient.unit} (Min: ${ingredient.minStock} ${ingredient.unit}). Please reorder from supplier.",
                            date = sale.date,
                            isRead = false
                        )
                    )
                }
            }
        }
    }

    /**
     * Records a purchase and automatically:
     * 1. Inserts the Purchase
     * 2. Updates the ingredient stock (adds purchased quantity)
     * 3. Re-calculates moving average cost for the ingredient
     * 4. Inserts an InventoryTransaction of type "Purchase"
     */
    suspend fun recordPurchase(purchase: Purchase) = withContext(Dispatchers.IO) {
        db.purchaseDao().insertPurchase(purchase)

        val ingredient = db.ingredientDao().getIngredientByIdSync(purchase.ingredientId)
        if (ingredient != null) {
            val oldStock = ingredient.currentStock
            val newStock = oldStock + purchase.quantity

            // Moving Average Cost calculation
            val oldTotalVal = oldStock * ingredient.averageCost
            val newPurchaseVal = purchase.quantity * purchase.price
            val newAverageCost = if (newStock > 0.0) {
                (oldTotalVal + newPurchaseVal) / newStock
            } else {
                purchase.price
            }

            db.ingredientDao().updateIngredient(
                ingredient.copy(
                    currentStock = newStock,
                    averageCost = newAverageCost,
                    purchaseCost = purchase.price
                )
            )

            db.inventoryTransactionDao().insertTransaction(
                InventoryTransaction(
                    ingredientId = ingredient.id,
                    type = "Purchase",
                    quantity = purchase.quantity,
                    cost = purchase.price * purchase.quantity,
                    date = purchase.date,
                    notes = "Purchased ${purchase.quantity} ${ingredient.unit} from Supplier #${purchase.supplierId}"
                )
            )
        }
    }

    // --- Seeding Database with Real Menu, Recipes, Ingredients & Historic Metrics ---

    suspend fun seedDatabaseIfEmpty() = withContext(Dispatchers.IO) {
        val existingIngredients = db.ingredientDao().getAllIngredientsSync()
        if (existingIngredients.isNotEmpty()) {
            return@withContext // Database already has data
        }

        // 1. Seed Suppliers
        val sup1Id = db.supplierDao().insertSupplier(Supplier(name = "Global Foods Corp", phone = "555-0199", email = "orders@globalfoods.com", address = "123 Bulk Road, Food City")).toInt()
        val sup2Id = db.supplierDao().insertSupplier(Supplier(name = "Fresh Farms Agri", phone = "555-0144", email = "fresh@farms.com", address = "456 Valley Lane, Green Field")).toInt()
        val sup3Id = db.supplierDao().insertSupplier(Supplier(name = "Spice Kingdom", phone = "555-0122", email = "info@spicekingdom.com", address = "789 Flavor Street, Spice Town")).toInt()

        // 2. Seed Ingredients
        val ingList = listOf(
            Ingredient(name = "Flour", currentStock = 500.0, minStock = 150.0, maxStock = 1000.0, supplierId = sup1Id, averageCost = 0.80, purchaseCost = 0.80, unit = "kg"),
            Ingredient(name = "Salt", currentStock = 50.0, minStock = 10.0, maxStock = 100.0, supplierId = sup1Id, averageCost = 0.15, purchaseCost = 0.15, unit = "kg"),
            Ingredient(name = "Water", currentStock = 1000.0, minStock = 200.0, maxStock = 2000.0, supplierId = null, averageCost = 0.01, purchaseCost = 0.01, unit = "L"),
            Ingredient(name = "Yeast", currentStock = 20.0, minStock = 5.0, maxStock = 50.0, supplierId = sup1Id, averageCost = 3.50, purchaseCost = 3.50, unit = "kg"),
            Ingredient(name = "Milk", currentStock = 100.0, minStock = 20.0, maxStock = 200.0, supplierId = sup2Id, averageCost = 1.20, purchaseCost = 1.20, unit = "L"),
            Ingredient(name = "Wheat", currentStock = 300.0, minStock = 100.0, maxStock = 600.0, supplierId = sup2Id, averageCost = 0.90, purchaseCost = 0.90, unit = "kg"),
            Ingredient(name = "Lentils", currentStock = 150.0, minStock = 50.0, maxStock = 300.0, supplierId = sup2Id, averageCost = 1.50, purchaseCost = 1.50, unit = "kg"),
            Ingredient(name = "Chicken", currentStock = 200.0, minStock = 40.0, maxStock = 400.0, supplierId = sup2Id, averageCost = 4.50, purchaseCost = 4.50, unit = "kg"),
            Ingredient(name = "Spices", currentStock = 40.0, minStock = 10.0, maxStock = 100.0, supplierId = sup3Id, averageCost = 6.00, purchaseCost = 6.00, unit = "kg"),
            Ingredient(name = "Oil", currentStock = 150.0, minStock = 30.0, maxStock = 300.0, supplierId = sup1Id, averageCost = 2.00, purchaseCost = 2.00, unit = "L"),
            Ingredient(name = "Tomatoes", currentStock = 120.0, minStock = 30.0, maxStock = 200.0, supplierId = sup2Id, averageCost = 1.80, purchaseCost = 1.80, unit = "kg"),
            Ingredient(name = "Ginger Garlic", currentStock = 30.0, minStock = 10.0, maxStock = 60.0, supplierId = sup2Id, averageCost = 2.50, purchaseCost = 2.50, unit = "kg"),
            Ingredient(name = "Cheese", currentStock = 80.0, minStock = 20.0, maxStock = 150.0, supplierId = sup1Id, averageCost = 8.00, purchaseCost = 8.00, unit = "kg"),
            Ingredient(name = "Tomato Sauce", currentStock = 60.0, minStock = 15.0, maxStock = 100.0, supplierId = sup1Id, averageCost = 2.20, purchaseCost = 2.20, unit = "kg"),
            Ingredient(name = "Bell Pepper", currentStock = 40.0, minStock = 10.0, maxStock = 80.0, supplierId = sup2Id, averageCost = 2.00, purchaseCost = 2.00, unit = "kg")
        )

        val ingredientIds = ingList.associate { ing ->
            val id = db.ingredientDao().insertIngredient(ing).toInt()
            ing.name to id
        }

        // 3. Seed Menu Items
        val menuList = listOf(
            MenuItem(name = "Roti", category = "Starters", sellingPrice = 1.00, description = "Traditional clay-oven flatbread.", status = "Active"),
            MenuItem(name = "Haleem", category = "Mains", sellingPrice = 8.50, description = "Slow-cooked stew of wheat, lentils, beef/chicken, and aromatic spices.", status = "Active"),
            MenuItem(name = "Naan", category = "Starters", sellingPrice = 1.50, description = "Soft, leavened flatbread freshly baked in tandoor.", status = "Active"),
            MenuItem(name = "Chicken Karahi", category = "Mains", sellingPrice = 18.00, description = "Spicy stir-fry chicken wok with tomatoes and fresh green chilies.", status = "Active"),
            MenuItem(name = "Pizza", category = "Mains", sellingPrice = 14.00, description = "Delicious thin-crust chicken fajita pizza with cheese and peppers.", status = "Active")
        )

        val menuIds = menuList.associate { menu ->
            val id = db.menuItemDao().insertMenuItem(menu).toInt()
            menu.name to id
        }

        // Helper to get ingredient ID safely
        fun getIngId(name: String): Int = ingredientIds[name] ?: 1

        // 4. Seed Recipes (Menu Item ID -> List of Recipe Ingredients)
        // Roti
        val rotiId = menuIds["Roti"] ?: 1
        db.recipeIngredientDao().insertRecipeIngredient(RecipeIngredient(rotiId, getIngId("Flour"), 0.10, "kg"))
        db.recipeIngredientDao().insertRecipeIngredient(RecipeIngredient(rotiId, getIngId("Salt"), 0.002, "kg"))
        db.recipeIngredientDao().insertRecipeIngredient(RecipeIngredient(rotiId, getIngId("Water"), 0.06, "L"))

        // Haleem
        val haleemId = menuIds["Haleem"] ?: 2
        db.recipeIngredientDao().insertRecipeIngredient(RecipeIngredient(haleemId, getIngId("Wheat"), 0.05, "kg"))
        db.recipeIngredientDao().insertRecipeIngredient(RecipeIngredient(haleemId, getIngId("Lentils"), 0.03, "kg"))
        db.recipeIngredientDao().insertRecipeIngredient(RecipeIngredient(haleemId, getIngId("Chicken"), 0.12, "kg"))
        db.recipeIngredientDao().insertRecipeIngredient(RecipeIngredient(haleemId, getIngId("Spices"), 0.01, "kg"))
        db.recipeIngredientDao().insertRecipeIngredient(RecipeIngredient(haleemId, getIngId("Oil"), 0.02, "L"))

        // Naan
        val naanId = menuIds["Naan"] ?: 3
        db.recipeIngredientDao().insertRecipeIngredient(RecipeIngredient(naanId, getIngId("Flour"), 0.12, "kg"))
        db.recipeIngredientDao().insertRecipeIngredient(RecipeIngredient(naanId, getIngId("Yeast"), 0.005, "kg"))
        db.recipeIngredientDao().insertRecipeIngredient(RecipeIngredient(naanId, getIngId("Milk"), 0.04, "L"))
        db.recipeIngredientDao().insertRecipeIngredient(RecipeIngredient(naanId, getIngId("Salt"), 0.002, "kg"))

        // Chicken Karahi
        val karahiId = menuIds["Chicken Karahi"] ?: 4
        db.recipeIngredientDao().insertRecipeIngredient(RecipeIngredient(karahiId, getIngId("Chicken"), 0.80, "kg"))
        db.recipeIngredientDao().insertRecipeIngredient(RecipeIngredient(karahiId, getIngId("Tomatoes"), 0.30, "kg"))
        db.recipeIngredientDao().insertRecipeIngredient(RecipeIngredient(karahiId, getIngId("Ginger Garlic"), 0.05, "kg"))
        db.recipeIngredientDao().insertRecipeIngredient(RecipeIngredient(karahiId, getIngId("Spices"), 0.03, "kg"))
        db.recipeIngredientDao().insertRecipeIngredient(RecipeIngredient(karahiId, getIngId("Oil"), 0.10, "L"))

        // Pizza
        val pizzaId = menuIds["Pizza"] ?: 5
        db.recipeIngredientDao().insertRecipeIngredient(RecipeIngredient(pizzaId, getIngId("Flour"), 0.25, "kg"))
        db.recipeIngredientDao().insertRecipeIngredient(RecipeIngredient(pizzaId, getIngId("Cheese"), 0.15, "kg"))
        db.recipeIngredientDao().insertRecipeIngredient(RecipeIngredient(pizzaId, getIngId("Tomato Sauce"), 0.08, "kg"))
        db.recipeIngredientDao().insertRecipeIngredient(RecipeIngredient(pizzaId, getIngId("Chicken"), 0.10, "kg"))
        db.recipeIngredientDao().insertRecipeIngredient(RecipeIngredient(pizzaId, getIngId("Bell Pepper"), 0.05, "kg"))

        // 5. Seed Employees
        db.employeeDao().insertEmployee(Employee(name = "John Doe", role = "Owner", email = "john@biteflow.com", phone = "555-0100"))
        db.employeeDao().insertEmployee(Employee(name = "Sarah Smith", role = "Admin", email = "sarah@biteflow.com", phone = "555-0101"))
        db.employeeDao().insertEmployee(Employee(name = "Mike Miller", role = "Manager", email = "mike@biteflow.com", phone = "555-0102"))
        db.employeeDao().insertEmployee(Employee(name = "Emma Watson", role = "Cashier", email = "emma@biteflow.com", phone = "555-0103"))
        db.employeeDao().insertEmployee(Employee(name = "David Kim", role = "Kitchen Staff", email = "david@biteflow.com", phone = "555-0104"))

        // 6. Seed Expenses (Rent, Salaries, Utilities)
        val sdf = SimpleDateFormat("yyyy-MM-DD", Locale.US)
        val todayStr = sdf.format(Date())
        
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -10)
        val tenDaysAgo = sdf.format(cal.time)
        cal.add(Calendar.DAY_OF_YEAR, 5)
        val fiveDaysAgo = sdf.format(cal.time)

        db.expenseDao().insertExpense(Expense(category = "Rent", amount = 1500.0, date = tenDaysAgo, notes = "Monthly outlet rent"))
        db.expenseDao().insertExpense(Expense(category = "Salary", amount = 2500.0, date = tenDaysAgo, notes = "Staff payroll for previous month"))
        db.expenseDao().insertExpense(Expense(category = "Utilities", amount = 450.0, date = fiveDaysAgo, notes = "Electricity and water bills"))
        db.expenseDao().insertExpense(Expense(category = "Marketing", amount = 200.0, date = todayStr, notes = "Social media sponsored campaigns"))
        db.expenseDao().insertExpense(Expense(category = "Packaging", amount = 120.0, date = todayStr, notes = "Takeaway custom box supplier payment"))

        // 7. Seed Purchases
        recordPurchase(Purchase(supplierId = sup1Id, ingredientId = getIngId("Flour"), quantity = 100.0, price = 0.75, date = tenDaysAgo, invoiceNumber = "INV-10023"))
        recordPurchase(Purchase(supplierId = sup2Id, ingredientId = getIngId("Chicken"), quantity = 50.0, price = 4.20, date = tenDaysAgo, invoiceNumber = "INV-10024"))
        recordPurchase(Purchase(supplierId = sup1Id, ingredientId = getIngId("Cheese"), quantity = 20.0, price = 7.80, date = fiveDaysAgo, invoiceNumber = "INV-10041"))
        recordPurchase(Purchase(supplierId = sup3Id, ingredientId = getIngId("Spices"), quantity = 10.0, price = 5.50, date = fiveDaysAgo, invoiceNumber = "INV-10042"))

        // 8. Seed Historic Sales (so that graphs have beautiful shapes)
        // Today's Sales:
        recordSale(
            Sale(date = todayStr, time = "12:30:00", notes = "Lunch Rush Party", totalAmount = 350.0),
            listOf(
                SaleItem(saleId = 0, menuItemId = rotiId, quantity = 50, priceAtSale = 1.00),
                SaleItem(saleId = 0, menuItemId = naanId, quantity = 30, priceAtSale = 1.50),
                SaleItem(saleId = 0, menuItemId = haleemId, quantity = 15, priceAtSale = 8.50),
                SaleItem(saleId = 0, menuItemId = karahiId, quantity = 4, priceAtSale = 18.00),
                SaleItem(saleId = 0, menuItemId = pizzaId, quantity = 4, priceAtSale = 14.00)
            )
        )

        recordSale(
            Sale(date = todayStr, time = "19:45:00", notes = "Dinner Rush Orders", totalAmount = 520.0),
            listOf(
                SaleItem(saleId = 0, menuItemId = rotiId, quantity = 100, priceAtSale = 1.00),
                SaleItem(saleId = 0, menuItemId = naanId, quantity = 60, priceAtSale = 1.50),
                SaleItem(saleId = 0, menuItemId = haleemId, quantity = 20, priceAtSale = 8.50),
                SaleItem(saleId = 0, menuItemId = karahiId, quantity = 8, priceAtSale = 18.00),
                SaleItem(saleId = 0, menuItemId = pizzaId, quantity = 5, priceAtSale = 14.00)
            )
        )

        // Seed 5 days ago Sales:
        recordSale(
            Sale(date = fiveDaysAgo, time = "13:00:00", notes = "Corporate Catering", totalAmount = 750.0),
            listOf(
                SaleItem(saleId = 0, menuItemId = rotiId, quantity = 200, priceAtSale = 1.00),
                SaleItem(saleId = 0, menuItemId = naanId, quantity = 100, priceAtSale = 1.50),
                SaleItem(saleId = 0, menuItemId = haleemId, quantity = 30, priceAtSale = 8.50),
                SaleItem(saleId = 0, menuItemId = karahiId, quantity = 10, priceAtSale = 18.00),
                SaleItem(saleId = 0, menuItemId = pizzaId, quantity = 5, priceAtSale = 14.00)
            )
        )

        // Prepopulate standard notifications
        db.notificationDao().insertNotification(
            AppNotification(
                type = "Low Stock",
                title = "Yeast Stock Warning",
                message = "Yeast current stock is 20.0 kg, which is approaching min threshold.",
                date = todayStr,
                isRead = false
            )
        )
        db.notificationDao().insertNotification(
            AppNotification(
                type = "Expiring",
                title = "Milk Expiry Warning",
                message = "Milk batch from Supplier #2 expires in 3 days. Use promptly.",
                date = todayStr,
                isRead = false
            )
        )
    }
}

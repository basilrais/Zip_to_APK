package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "employees")
data class Employee(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val role: String, // "Owner", "Admin", "Manager", "Cashier", "Kitchen Staff"
    val email: String,
    val phone: String
)

@Entity(tableName = "ingredients")
data class Ingredient(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val currentStock: Double,
    val minStock: Double,
    val maxStock: Double,
    val supplierId: Int?,
    val averageCost: Double,
    val purchaseCost: Double,
    val unit: String, // "kg", "L", "pcs", "g", "ml"
    val expiryDate: String? = null // YYYY-MM-DD
) {
    val inventoryValue: Double
        get() = currentStock * averageCost
}

@Entity(tableName = "menu_items")
data class MenuItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val category: String, // "Mains", "Starters", "Desserts", "Beverages"
    val sellingPrice: Double,
    val description: String,
    val imageUrl: String? = null,
    val status: String = "Active" // "Active", "Inactive"
)

@Entity(tableName = "recipe_ingredients", primaryKeys = ["menuItemId", "ingredientId"])
data class RecipeIngredient(
    val menuItemId: Int,
    val ingredientId: Int,
    val quantity: Double,
    val unit: String
)

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String, // YYYY-MM-DD
    val time: String, // HH:MM:SS
    val notes: String = "",
    val totalAmount: Double = 0.0,
    val cashierId: Int? = null
)

@Entity(tableName = "sale_items")
data class SaleItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val saleId: Int,
    val menuItemId: Int,
    val quantity: Int,
    val priceAtSale: Double
)

@Entity(tableName = "inventory_transactions")
data class InventoryTransaction(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val ingredientId: Int,
    val type: String, // "Purchase", "Sale", "Adjustment", "Waste", "Theft"
    val quantity: Double, // Negative for usage/loss, positive for purchase/addition
    val cost: Double,
    val date: String, // YYYY-MM-DD
    val notes: String = ""
)

@Entity(tableName = "suppliers")
data class Supplier(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val phone: String,
    val email: String,
    val address: String
)

@Entity(tableName = "purchases")
data class Purchase(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val supplierId: Int,
    val ingredientId: Int,
    val quantity: Double,
    val price: Double,
    val date: String, // YYYY-MM-DD
    val invoiceNumber: String
)

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val category: String, // "Salary", "Rent", "Utilities", "Maintenance", "Fuel", "Marketing", "Packaging", "Cleaning", "Miscellaneous"
    val amount: Double,
    val date: String, // YYYY-MM-DD
    val notes: String = ""
)

@Entity(tableName = "notifications")
data class AppNotification(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val type: String, // "Low Stock", "Expiring", "Payment", "Expense", "Summary"
    val title: String,
    val message: String,
    val date: String, // YYYY-MM-DD
    val isRead: Boolean = false
)

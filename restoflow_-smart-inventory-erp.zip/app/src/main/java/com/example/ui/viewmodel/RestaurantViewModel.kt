package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.api.GeminiClient
import com.example.data.database.AppDatabase
import com.example.data.model.*
import com.example.data.repository.RestaurantRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class RestaurantViewModel(
    application: Application,
    private val repository: RestaurantRepository
) : AndroidViewModel(application) {

    // Active User Role (Owner, Admin, Manager, Cashier, Kitchen Staff)
    private val _currentRole = MutableStateFlow("Owner")
    val currentRole: StateFlow<String> = _currentRole.asStateFlow()

    // Database flows
    val ingredients = repository.allIngredients.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val menuItems = repository.allMenuItems.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val sales = repository.allSales.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val transactions = repository.allTransactions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val suppliers = repository.allSuppliers.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val purchases = repository.allPurchases.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val expenses = repository.allExpenses.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val employees = repository.allEmployees.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val notifications = repository.allNotifications.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI State for AI Insights
    private val _aiInsights = MutableStateFlow<AiState>(AiState.Idle)
    val aiInsights: StateFlow<AiState> = _aiInsights.asStateFlow()

    // Sale creation state (cart of MenuItem ID -> Quantity)
    private val _saleCart = MutableStateFlow<Map<Int, Int>>(emptyMap())
    val saleCart: StateFlow<Map<Int, Int>> = _saleCart.asStateFlow()

    init {
        // Automatically seed database on launch if empty
        viewModelScope.launch {
            repository.seedDatabaseIfEmpty()
        }
    }

    fun setRole(role: String) {
        _currentRole.value = role
    }

    // --- Permissions helper ---
    fun hasPermission(action: String): Boolean {
        val role = _currentRole.value
        return when (action) {
            "view_financials", "manage_expenses", "manage_employees" -> role == "Owner" || role == "Admin"
            "manage_menu", "manage_recipes", "manage_suppliers" -> role == "Owner" || role == "Admin" || role == "Manager"
            "record_purchase", "manage_inventory" -> role == "Owner" || role == "Admin" || role == "Manager" || role == "Kitchen Staff"
            "record_sale" -> role == "Owner" || role == "Admin" || role == "Manager" || role == "Cashier"
            else -> true
        }
    }

    // --- Date Formatting Helpers ---
    private fun getTodayDateString(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }

    private fun isWithinDays(dateStr: String, days: Int): Boolean {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val date = sdf.parse(dateStr) ?: return false
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, -days)
            date.after(cal.time)
        } catch (e: Exception) {
            false
        }
    }

    // --- Financial Metrics Calculations ---

    val todayRevenue: StateFlow<Double> = sales.map { list ->
        val today = getTodayDateString()
        list.filter { it.date == today }.sumOf { it.totalAmount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val todayExpenses: StateFlow<Double> = combine(expenses, purchases) { expList, purList ->
        val today = getTodayDateString()
        val expSum = expList.filter { it.date == today }.sumOf { it.amount }
        val purSum = purList.filter { it.date == today }.sumOf { it.quantity * it.price }
        expSum + purSum
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val todayProfit: StateFlow<Double> = combine(todayRevenue, todayExpenses) { rev, exp ->
        rev - exp
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val monthlyRevenue: StateFlow<Double> = sales.map { list ->
        list.filter { isWithinDays(it.date, 30) }.sumOf { it.totalAmount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val monthlyExpenses: StateFlow<Double> = combine(expenses, purchases) { expList, purList ->
        val expSum = expList.filter { isWithinDays(it.date, 30) }.sumOf { it.amount }
        val purSum = purList.filter { isWithinDays(it.date, 30) }.sumOf { it.quantity * it.price }
        expSum + purSum
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val monthlyProfit: StateFlow<Double> = combine(monthlyRevenue, monthlyExpenses) { rev, exp ->
        rev - exp
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val inventoryValue: StateFlow<Double> = ingredients.map { list ->
        list.sumOf { it.currentStock * it.averageCost }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Calculate dynamic Cost of Goods Sold (COGS) to compute exact Food Cost %
    val foodCostPercentage: StateFlow<Double> = combine(sales, ingredients, menuItems) { salesList, ingList, menuList ->
        viewModelScope.launch {
            // Pre-calculate recipe ingredients for mapping in background
        }
        // Simplified but realistic food cost percentage:
        // COGS = sum(sales_quantity * recipe_cost)
        // Let's compute recipe costs first:
        var totalCogs = 0.0
        var totalFoodRevenue = 0.0

        // Synchronously load recipe ingredients
        val recipes = repository.recipeIngredientDao.getAllRecipeIngredientsSync()
        val ingMap = ingList.associateBy { it.id }
        val menuMap = menuList.associateBy { it.id }

        val saleItems = repository.saleItemDao.getAllSaleItemsSync()
        for (item in saleItems) {
            val menuItem = menuMap[item.menuItemId] ?: continue
            totalFoodRevenue += item.quantity * item.priceAtSale

            val menuRecipe = recipes.filter { it.menuItemId == item.menuItemId }
            var recipeCost = 0.0
            for (recIng in menuRecipe) {
                val ing = ingMap[recIng.ingredientId]
                if (ing != null) {
                    recipeCost += recIng.quantity * ing.averageCost
                }
            }
            totalCogs += item.quantity * recipeCost
        }

        if (totalFoodRevenue > 0) (totalCogs / totalFoodRevenue) * 100.0 else 28.5 // Standard fallback
    }.flowOn(Dispatchers.IO)
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 28.5)

    // --- Dynamic Analytics & Top Performance Lists ---

    val lowStockItems: StateFlow<List<Ingredient>> = ingredients.map { list ->
        list.filter { it.currentStock < it.minStock }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bestSellingItems: StateFlow<List<Pair<MenuItem, Int>>> = combine(menuItems, sales) { menuList, salesList ->
        val saleItems = repository.saleItemDao.getAllSaleItemsSync()
        val counts = saleItems.groupBy { it.menuItemId }.mapValues { entry -> entry.value.sumOf { it.quantity } }
        menuList.map { item -> item to (counts[item.id] ?: 0) }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
    }.flowOn(Dispatchers.IO)
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Cart Actions ---

    fun addToCart(menuItemId: Int) {
        val current = _saleCart.value.toMutableMap()
        current[menuItemId] = (current[menuItemId] ?: 0) + 1
        _saleCart.value = current
    }

    fun addToCartWithQty(menuItemId: Int, quantity: Int) {
        val current = _saleCart.value.toMutableMap()
        val addQty = if (quantity > 0) quantity else 1
        current[menuItemId] = (current[menuItemId] ?: 0) + addQty
        _saleCart.value = current
    }

    fun updateCartQuantity(menuItemId: Int, quantity: Int) {
        val current = _saleCart.value.toMutableMap()
        if (quantity <= 0) {
            current.remove(menuItemId)
        } else {
            current[menuItemId] = quantity
        }
        _saleCart.value = current
    }

    fun removeFromCart(menuItemId: Int) {
        val current = _saleCart.value.toMutableMap()
        val count = current[menuItemId] ?: 0
        if (count <= 1) {
            current.remove(menuItemId)
        } else {
            current[menuItemId] = count - 1
        }
        _saleCart.value = current
    }

    fun clearCart() {
        _saleCart.value = emptyMap()
    }

    // --- Record Actions (Called from Screen forms) ---

    fun recordSalesCheckout(notes: String) {
        val cart = _saleCart.value
        if (cart.isEmpty()) return

        viewModelScope.launch {
            val sdfDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            val sdfTime = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())

            val menuMap = menuItems.value.associateBy { it.id }
            var total = 0.0
            val itemsList = cart.map { (itemId, qty) ->
                val price = menuMap[itemId]?.sellingPrice ?: 0.0
                total += price * qty
                SaleItem(
                    saleId = 0,
                    menuItemId = itemId,
                    quantity = qty,
                    priceAtSale = price
                )
            }

            val sale = Sale(
                date = sdfDate,
                time = sdfTime,
                notes = notes,
                totalAmount = total
            )

            repository.recordSale(sale, itemsList)
            clearCart()
        }
    }

    fun addMenuItem(name: String, category: String, sellingPrice: Double, description: String, status: String) {
        viewModelScope.launch {
            repository.menuItemDao.insertMenuItem(
                MenuItem(
                    name = name,
                    category = category,
                    sellingPrice = sellingPrice,
                    description = description,
                    status = status
                )
            )
        }
    }

    fun addSupplier(name: String, phone: String, email: String, address: String) {
        viewModelScope.launch {
            repository.supplierDao.insertSupplier(
                Supplier(name = name, phone = phone, email = email, address = address)
            )
        }
    }

    fun addEmployee(name: String, role: String, email: String, phone: String) {
        viewModelScope.launch {
            repository.employeeDao.insertEmployee(
                Employee(name = name, role = role, email = email, phone = phone)
            )
        }
    }

    fun deleteEmployee(employee: Employee) {
        viewModelScope.launch {
            repository.employeeDao.deleteEmployee(employee)
        }
    }

    fun addIngredient(name: String, minStock: Double, maxStock: Double, unit: String, supplierId: Int?) {
        viewModelScope.launch {
            repository.ingredientDao.insertIngredient(
                Ingredient(
                    name = name,
                    currentStock = 0.0,
                    minStock = minStock,
                    maxStock = maxStock,
                    supplierId = supplierId,
                    averageCost = 0.0,
                    purchaseCost = 0.0,
                    unit = unit
                )
            )
        }
    }

    fun recordPurchaseEntry(ingredientId: Int, supplierId: Int, quantity: Double, price: Double, invoiceNumber: String) {
        viewModelScope.launch {
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            val purchase = Purchase(
                supplierId = supplierId,
                ingredientId = ingredientId,
                quantity = quantity,
                price = price,
                date = todayStr,
                invoiceNumber = invoiceNumber
            )
            repository.recordPurchase(purchase)
        }
    }

    fun recordExpenseEntry(category: String, amount: Double, notes: String) {
        viewModelScope.launch {
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            repository.expenseDao.insertExpense(
                Expense(category = category, amount = amount, date = todayStr, notes = notes)
            )
        }
    }

    fun addRecipeIngredientEntry(menuItemId: Int, ingredientId: Int, quantity: Double, unit: String) {
        viewModelScope.launch {
            repository.recipeIngredientDao.insertRecipeIngredient(
                RecipeIngredient(menuItemId, ingredientId, quantity, unit)
            )
        }
    }

    fun clearRecipeForMenuItem(menuItemId: Int) {
        viewModelScope.launch {
            repository.recipeIngredientDao.deleteRecipeIngredientsForMenuItem(menuItemId)
        }
    }

    // --- Reports Generation & Exporting ---

    fun generateReportText(reportType: String): String {
        val salesList = sales.value
        val expensesList = expenses.value
        val ingredientsList = ingredients.value
        val sb = StringBuilder()
        
        sb.append("=========================================\n")
        sb.append("         RESTAURANT ERP REPORT           \n")
        sb.append("=========================================\n")
        sb.append("Generated On: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}\n")
        sb.append("Report Type: ${reportType.uppercase(Locale.US)}\n\n")

        when (reportType.lowercase(Locale.US)) {
            "sales" -> {
                sb.append("DATE       | TIME     | REVENUE | NOTES\n")
                sb.append("-----------------------------------------\n")
                salesList.forEach {
                    sb.append("${it.date} | ${it.time} | Rs.${String.format("%.2f", it.totalAmount)} | ${it.notes}\n")
                }
                sb.append("\nTotal Sales Volume: Rs.${String.format("%.2f", salesList.sumOf { it.totalAmount })}\n")
            }
            "expenses" -> {
                sb.append("DATE       | CATEGORY    | AMOUNT | NOTES\n")
                sb.append("-----------------------------------------\n")
                expensesList.forEach {
                    sb.append("${it.date} | ${it.category.padEnd(11)} | Rs.${String.format("%.2f", it.amount)} | ${it.notes}\n")
                }
                sb.append("\nTotal Expenses Volume: Rs.${String.format("%.2f", expensesList.sumOf { it.amount })}\n")
            }
            "inventory" -> {
                sb.append("INGREDIENT      | STOCK  | UNIT | VALUE\n")
                sb.append("-----------------------------------------\n")
                ingredientsList.forEach {
                    val value = it.currentStock * it.averageCost
                    sb.append("${it.name.padEnd(15)} | ${String.format("%.2f", it.currentStock).padEnd(6)} | ${it.unit.padEnd(4)} | Rs.${String.format("%.2f", value)}\n")
                }
                sb.append("\nTotal Inventory Value: Rs.${String.format("%.2f", ingredientsList.sumOf { it.currentStock * it.averageCost })}\n")
            }
            else -> {
                sb.append("Summary Overview:\n")
                sb.append("Total Revenue: Rs.${String.format("%.2f", salesList.sumOf { it.totalAmount })}\n")
                sb.append("Total Expenses: Rs.${String.format("%.2f", expensesList.sumOf { it.amount })}\n")
                sb.append("Total Inventory Value: Rs.${String.format("%.2f", ingredientsList.sumOf { it.currentStock * it.averageCost })}\n")
            }
        }
        return sb.toString()
    }

    // --- Gemini AI Analysis and Forecasts ---

    fun fetchAiInsights() {
        _aiInsights.value = AiState.Loading
        viewModelScope.launch {
            // Compile a rich summary of our current ERP state to feed to Gemini
            val ingList = ingredients.value
            val salesList = sales.value
            val expList = expenses.value

            val lowStockStr = ingList.filter { it.currentStock < it.minStock }.joinToString { "${it.name} (${it.currentStock} ${it.unit} / Min: ${it.minStock})" }
            val recentSalesTotal = salesList.take(5).sumOf { it.totalAmount }
            val recentExpensesTotal = expList.take(5).sumOf { it.amount }

            val prompt = """
                You are the AI consultant built into the BiteFlow Restaurant ERP system.
                Analyze the restaurant's operational parameters and provide actionable advice.
                
                CURRENT OPERATIONAL DATA:
                - Ingredients in Critical Low Stock: [ $lowStockStr ]
                - Total Unique Menu Items: ${menuItems.value.size}
                - Total Registered Suppliers: ${suppliers.value.size}
                - Recent 5 Sales Cumulative Revenue: $recentSalesTotal
                - Recent 5 Logged Expenses Cumulative: $recentExpensesTotal
                - Total Current Inventory Book Value: Rs.${String.format("%.2f", inventoryValue.value)}
                
                Please generate a comprehensive audit report divided into the following exact sections with crisp, bulleted recommendations:
                1. TODAY'S SUMMARY: A professional opening assessment.
                2. LOW STOCK WARNINGS: Analysis of current critical ingredients.
                3. INVENTORY PREDICTIONS: Forecast which ingredients are at risk next.
                4. PROFIT & EXPENSE ANALYSIS: Review financial health.
                5. SALES & INGREDIENT FORECAST: Predict demand trends for menu items based on seed inventory.
                6. WASTE & THEFT DETECTION: Suggest control points for kitchen waste.
                7. STRATEGIC RECOMMENDATIONS: 3 highly practical business advice points.
                
                Make it look highly professional and clear. Avoid engineering jargon. Speak directly to the restaurant owner.
            """.trimIndent()

            val result = GeminiClient.getAiInsights(prompt)
            _aiInsights.value = AiState.Success(result)
        }
    }
}

sealed interface AiState {
    object Idle : AiState
    object Loading : AiState
    data class Success(val response: String) : AiState
    data class Error(val error: String) : AiState
}

class RestaurantViewModelFactory(
    private val application: Application,
    private val repository: RestaurantRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(RestaurantViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return RestaurantViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

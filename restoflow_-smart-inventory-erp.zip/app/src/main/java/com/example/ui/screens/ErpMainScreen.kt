package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.*
import com.example.ui.viewmodel.AiState
import com.example.ui.viewmodel.RestaurantViewModel
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ErpMainScreen(viewModel: RestaurantViewModel) {
    val context = LocalContext.current
    var activeTab by remember { mutableStateOf("dashboard") }
    var showNotificationDialog by remember { mutableStateOf(false) }

    val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val unreadCount = notifications.count { !it.isRead }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.RestaurantMenu,
                            contentDescription = "Logo",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "BiteFlow ERP",
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.SansSerif
                        )
                    }
                },
                actions = {
                    // Role Selector dropdown
                    var showRoleMenu by remember { mutableStateOf(false) }
                    Box(modifier = Modifier.padding(end = 8.dp)) {
                        Button(
                            onClick = { showRoleMenu = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                                contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                            ),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.testTag("role_selector_button")
                        ) {
                            Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = currentRole, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        DropdownMenu(
                            expanded = showRoleMenu,
                            onDismissRequest = { showRoleMenu = false }
                        ) {
                            listOf("Owner", "Admin", "Manager", "Cashier", "Kitchen Staff").forEach { role ->
                                DropdownMenuItem(
                                    text = { Text(role) },
                                    onClick = {
                                        viewModel.setRole(role)
                                        showRoleMenu = false
                                    }
                                )
                            }
                        }
                    }

                    // Notification bell icon
                    IconButton(
                        onClick = { showNotificationDialog = true },
                        modifier = Modifier.testTag("notification_bell_button")
                    ) {
                        BadgedBox(
                            badge = {
                                if (unreadCount > 0) {
                                    Badge(containerColor = MaterialTheme.colorScheme.error) {
                                        Text(unreadCount.toString(), color = Color.White)
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = if (unreadCount > 0) Icons.Default.NotificationsActive else Icons.Default.Notifications,
                                contentDescription = "Notifications"
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
                )
            )
        },
        bottomBar = {
            NavigationBar(
                windowInsets = WindowInsets.navigationBars,
                containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
            ) {
                val tabs = listOf(
                    NavigationItem("dashboard", "Dashboard", Icons.Default.Dashboard, Icons.Outlined.Dashboard),
                    NavigationItem("pos", "Sales / POS", Icons.Default.PointOfSale, Icons.Outlined.PointOfSale),
                    NavigationItem("inventory", "Inventory", Icons.Default.Warehouse, Icons.Outlined.Warehouse),
                    NavigationItem("suppliers", "Suppliers", Icons.Default.LocalShipping, Icons.Outlined.LocalShipping),
                    NavigationItem("ai", "AI Insights", Icons.Default.Psychology, Icons.Outlined.Psychology),
                    NavigationItem("reports", "Reports", Icons.Default.Assessment, Icons.Outlined.Assessment)
                )

                tabs.forEach { item ->
                    val isSelected = activeTab == item.id
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { activeTab = item.id },
                        label = { Text(item.title, fontSize = 10.sp, maxLines = 1) },
                        icon = {
                            Icon(
                                imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                contentDescription = item.title
                            )
                        },
                        modifier = Modifier.testTag("nav_tab_${item.id}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            AnimatedContent(
                targetState = activeTab,
                transitionSpec = {
                    fadeIn() togetherWith fadeOut()
                },
                label = "TabContent"
            ) { targetTab ->
                when (targetTab) {
                    "dashboard" -> DashboardTab(viewModel)
                    "pos" -> PosSalesTab(viewModel)
                    "inventory" -> InventoryTab(viewModel)
                    "suppliers" -> SuppliersExpensesTab(viewModel)
                    "ai" -> AiInsightsTab(viewModel)
                    "reports" -> ReportsTab(viewModel)
                }
            }
        }
    }

    // Notifications Dialog
    if (showNotificationDialog) {
        AlertDialog(
            onDismissRequest = { showNotificationDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Notifications, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("ERP System Notifications")
                }
            },
            text = {
                Box(modifier = Modifier.sizeIn(maxHeight = 400.dp)) {
                    if (notifications.isEmpty()) {
                        Text(
                            "No active alerts. Inventory stock is healthy and supplier payments are up to date.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(notifications) { item ->
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (item.isRead) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = item.title,
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = if (item.type == "Low Stock") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(text = item.date, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(text = item.message, style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showNotificationDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}

data class NavigationItem(
    val id: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

// ==========================================
// 1. DASHBOARD TAB
// ==========================================
@Composable
fun DashboardTab(viewModel: RestaurantViewModel) {
    val todayRev by viewModel.todayRevenue.collectAsStateWithLifecycle()
    val todayExp by viewModel.todayExpenses.collectAsStateWithLifecycle()
    val todayProf by viewModel.todayProfit.collectAsStateWithLifecycle()
    
    val monthRev by viewModel.monthlyRevenue.collectAsStateWithLifecycle()
    val monthExp by viewModel.monthlyExpenses.collectAsStateWithLifecycle()
    val monthProf by viewModel.monthlyProfit.collectAsStateWithLifecycle()

    val invVal by viewModel.inventoryValue.collectAsStateWithLifecycle()
    val foodCostPct by viewModel.foodCostPercentage.collectAsStateWithLifecycle()
    val lowStockList by viewModel.lowStockItems.collectAsStateWithLifecycle()
    val bestSellers by viewModel.bestSellingItems.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Header
        item {
            Column {
                Text(
                    text = "Operational Dashboard",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "BiteFlow Real-time ERP Diagnostics",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Today's Key Metrics
        item {
            Text("TODAY'S FINANCIALS", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricCard(
                    title = "Revenue",
                    value = "Rs. ${String.format("%.2f", todayRev)}",
                    icon = Icons.Default.TrendingUp,
                    color = Color(0xFF4CAF50),
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Expenses",
                    value = "Rs. ${String.format("%.2f", todayExp)}",
                    icon = Icons.Default.TrendingDown,
                    color = Color(0xFFF44336),
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Profit",
                    value = "Rs. ${String.format("%.2f", todayProf)}",
                    icon = Icons.Default.AttachMoney,
                    color = if (todayProf >= 0) Color(0xFF00bcd4) else Color(0xFFFF5722),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Monthly Financials & Stock Value
        item {
            Text("MONTHLY FINANCIALS & CAPITAL", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricCard(
                    title = "Monthly Rev",
                    value = "Rs. ${String.format("%.2f", monthRev)}",
                    icon = Icons.Default.Storefront,
                    color = Color(0xFF9C27B0),
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Monthly Profit",
                    value = "Rs. ${String.format("%.2f", monthProf)}",
                    icon = Icons.Default.MonetizationOn,
                    color = Color(0xFFE91E63),
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Inv Book Value",
                    value = "Rs. ${String.format("%.2f", invVal)}",
                    icon = Icons.Default.Inventory,
                    color = Color(0xFFFF9800),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Charts & KPIs
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Today vs Monthly Flow Breakdown", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    // Bar chart custom drawing
                    val chartData = listOf(
                        "Today Rev" to todayRev.toFloat(),
                        "Today Exp" to todayExp.toFloat(),
                        "Month Rev" to (monthRev / 10).toFloat(), // Scale down monthly slightly so they display nicely side by side
                        "Month Exp" to (monthExp / 10).toFloat()
                    )
                    CustomBarChart(
                        data = chartData,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("*Note: Monthly metrics are scaled down by 10x for visual clarity.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        // Best Sellers & Food Cost
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Food cost gauge card
                Card(
                    modifier = Modifier
                        .weight(1.2f)
                        .height(180.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text("Food Cost %", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        Spacer(modifier = Modifier.height(12.dp))
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(90.dp)) {
                            CircularProgressIndicator(
                                progress = { (foodCostPct / 100).toFloat().coerceIn(0f, 1f) },
                                modifier = Modifier.fillMaxSize(),
                                color = if (foodCostPct > 35) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                                strokeWidth = 8.dp
                            )
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${String.format("%.1f", foodCostPct)}%",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                                Text(
                                    text = if (foodCostPct <= 30) "Good" else "High",
                                    fontSize = 10.sp,
                                    color = if (foodCostPct <= 30) Color(0xFF4CAF50) else Color(0xFFF44336)
                                )
                            }
                        }
                    }
                }

                // Low Stock / Alerts Card
                Card(
                    modifier = Modifier
                        .weight(1.8f)
                        .height(180.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Low Stock Items", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.errorContainer)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    lowStockList.size.toString(),
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        if (lowStockList.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("All stock level healthy", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                items(lowStockList.take(3)) { item ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(item.name, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            text = "${String.format("%.1f", item.currentStock)} ${item.unit}",
                                            color = MaterialTheme.colorScheme.error,
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Best Selling Items
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Best Selling Menu Items", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))
                    if (bestSellers.isEmpty()) {
                        Text("No sales data generated yet today.", style = MaterialTheme.typography.bodySmall)
                    } else {
                        bestSellers.forEach { (menu, qty) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Restaurant, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(menu.name, fontWeight = FontWeight.SemiBold)
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(MaterialTheme.colorScheme.primaryContainer)
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "$qty Sold",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.height(105.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, style = MaterialTheme.typography.labelSmall, color = Color.Gray, fontWeight = FontWeight.Bold)
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
            }
            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

// ==========================================
// 2. POS SALES & MENU TAB
// ==========================================
@Composable
fun PosSalesTab(viewModel: RestaurantViewModel) {
    val items by viewModel.menuItems.collectAsStateWithLifecycle()
    val ingredientsList by viewModel.ingredients.collectAsStateWithLifecycle()
    val cart by viewModel.saleCart.collectAsStateWithLifecycle()
    var showCheckoutDialog by remember { mutableStateOf(false) }
    var notes by remember { mutableStateOf("") }

    // Forms for menu creation
    var showAddMenuForm by remember { mutableStateOf(false) }
    var menuName by remember { mutableStateOf("") }
    var menuCategory by remember { mutableStateOf("Mains") }
    var menuPrice by remember { mutableStateOf("") }
    var menuDesc by remember { mutableStateOf("") }

    // Forms for recipe management
    var showRecipeBuilder by remember { mutableStateOf(false) }
    var selectedMenuItemIdForRecipe by remember { mutableStateOf<Int?>(null) }
    var recipeIngredientId by remember { mutableStateOf<Int?>(null) }
    var recipeQty by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text("POS Checkout & Menu", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("Select menu items to check out", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
                }

                if (viewModel.hasPermission("manage_menu")) {
                    Button(
                        onClick = { showAddMenuForm = !showAddMenuForm },
                        modifier = Modifier.fillMaxWidth().testTag("add_item_button")
                    ) {
                        Icon(if (showAddMenuForm) Icons.Default.Close else Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (showAddMenuForm) "Hide Form" else "Add Item")
                    }
                }
            }
        }

        // Add Menu Item Form Collapsible
        if (showAddMenuForm) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Add New Menu Item", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        OutlinedTextField(
                            value = menuName,
                            onValueChange = { menuName = it },
                            label = { Text("Menu Item Name") },
                            modifier = Modifier.fillMaxWidth().testTag("menu_name_input")
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedTextField(
                                value = menuPrice,
                                onValueChange = { menuPrice = it },
                                label = { Text("Selling Price (Rs.)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.weight(1f).testTag("menu_price_input")
                            )
                            // Category Select
                            var expandedCat by remember { mutableStateOf(false) }
                            Box(modifier = Modifier.weight(1f).padding(top = 8.dp)) {
                                Button(onClick = { expandedCat = true }, modifier = Modifier.fillMaxWidth()) {
                                    Text(menuCategory)
                                }
                                DropdownMenu(expanded = expandedCat, onDismissRequest = { expandedCat = false }) {
                                    listOf("Mains", "Starters", "Desserts", "Beverages").forEach { cat ->
                                        DropdownMenuItem(text = { Text(cat) }, onClick = {
                                            menuCategory = cat
                                            expandedCat = false
                                        })
                                    }
                                }
                            }
                        }
                        OutlinedTextField(
                            value = menuDesc,
                            onValueChange = { menuDesc = it },
                            label = { Text("Short Description") },
                            modifier = Modifier.fillMaxWidth().testTag("menu_desc_input")
                        )
                        Button(
                            onClick = {
                                val price = menuPrice.toDoubleOrNull() ?: 0.0
                                if (menuName.isNotEmpty() && price > 0) {
                                    viewModel.addMenuItem(menuName, menuCategory, price, menuDesc, "Active")
                                    menuName = ""
                                    menuPrice = ""
                                    menuDesc = ""
                                    showAddMenuForm = false
                                }
                            },
                            modifier = Modifier.align(Alignment.End).testTag("save_menu_item_button")
                        ) {
                            Text("Save Menu Item")
                        }
                    }
                }
            }
        }

        // Recipe Builder Dialog/Form
        if (showRecipeBuilder && selectedMenuItemIdForRecipe != null) {
            val targetMenu = items.find { it.id == selectedMenuItemIdForRecipe }
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Recipe Builder for: ${targetMenu?.name}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        
                        // Select Ingredient
                        var expandedIng by remember { mutableStateOf(false) }
                        val selectedIng = ingredientsList.find { it.id == recipeIngredientId }
                        Box(modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(onClick = { expandedIng = true }, modifier = Modifier.fillMaxWidth()) {
                                Text(selectedIng?.name ?: "Select Ingredient")
                            }
                            DropdownMenu(expanded = expandedIng, onDismissRequest = { expandedIng = false }) {
                                ingredientsList.forEach { ing ->
                                    DropdownMenuItem(text = { Text("${ing.name} (${ing.unit})") }, onClick = {
                                        recipeIngredientId = ing.id
                                        expandedIng = false
                                    })
                                }
                            }
                        }

                        OutlinedTextField(
                            value = recipeQty,
                            onValueChange = { recipeQty = it },
                            label = { Text("Recipe Quantity") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            TextButton(onClick = {
                                viewModel.clearRecipeForMenuItem(selectedMenuItemIdForRecipe!!)
                            }) {
                                Text("Clear Current Recipe", color = MaterialTheme.colorScheme.error)
                            }

                            Row {
                                TextButton(onClick = { showRecipeBuilder = false }) {
                                    Text("Done")
                                }
                                Button(onClick = {
                                    val qty = recipeQty.toDoubleOrNull() ?: 0.0
                                    if (recipeIngredientId != null && qty > 0.0) {
                                        viewModel.addRecipeIngredientEntry(
                                            selectedMenuItemIdForRecipe!!,
                                            recipeIngredientId!!,
                                            qty,
                                            selectedIng?.unit ?: "kg"
                                        )
                                        recipeQty = ""
                                        recipeIngredientId = null
                                    }
                                }) {
                                    Text("Add Ingredient")
                                }
                            }
                        }
                    }
                }
            }
        }

        // Cart Checkout summary block
        if (cart.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("Current Checkout Cart", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            TextButton(onClick = { viewModel.clearCart() }) {
                                Text("Clear", color = MaterialTheme.colorScheme.error)
                            }
                        }
                        
                        val menuMap = items.associateBy { it.id }
                        var totalVal = 0.0
                        cart.forEach { (itemId, qty) ->
                            val menu = menuMap[itemId]
                            if (menu != null) {
                                totalVal += menu.sellingPrice * qty
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(menu.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                    }
                                    
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        modifier = Modifier.padding(horizontal = 8.dp)
                                    ) {
                                        IconButton(
                                            onClick = { viewModel.updateCartQuantity(itemId, qty - 1) },
                                            modifier = Modifier.size(28.dp).testTag("cart_dec_${itemId}")
                                        ) {
                                            Icon(Icons.Default.Remove, contentDescription = "Decrease", tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(16.dp))
                                        }

                                        var cartQtyText by remember(qty) { mutableStateOf(qty.toString()) }
                                        OutlinedTextField(
                                            value = cartQtyText,
                                            onValueChange = { newValue ->
                                                val filtered = newValue.filter { it.isDigit() }
                                                cartQtyText = filtered
                                                val parsed = filtered.toIntOrNull()
                                                if (parsed != null) {
                                                    if (parsed > 0) {
                                                        viewModel.updateCartQuantity(itemId, parsed)
                                                    } else if (parsed == 0) {
                                                        viewModel.updateCartQuantity(itemId, 0)
                                                    }
                                                }
                                            },
                                            singleLine = true,
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            modifier = Modifier
                                                .width(65.dp)
                                                .height(48.dp)
                                                .testTag("cart_qty_input_${itemId}"),
                                            textStyle = MaterialTheme.typography.bodyMedium.copy(textAlign = TextAlign.Center),
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedTextColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                                unfocusedTextColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                                focusedContainerColor = Color.Transparent,
                                                unfocusedContainerColor = Color.Transparent,
                                                focusedBorderColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                                unfocusedBorderColor = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.5f)
                                            )
                                        )

                                        IconButton(
                                            onClick = { viewModel.updateCartQuantity(itemId, qty + 1) },
                                            modifier = Modifier.size(28.dp).testTag("cart_inc_${itemId}")
                                        ) {
                                            Icon(Icons.Default.Add, contentDescription = "Increase", tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(16.dp))
                                        }
                                    }

                                    Text("Rs. ${String.format("%.2f", menu.sellingPrice * qty)}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                }
                            }
                        }

                        Divider(color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 8.dp))
                        
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("Total Checkout Due:", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text("Rs. ${String.format("%.2f", totalVal)}", fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.onPrimaryContainer, fontSize = 18.sp)
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { showCheckoutDialog = true },
                            modifier = Modifier.fillMaxWidth().testTag("checkout_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Default.ShoppingBag, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Checkout and Deduct Stock")
                        }
                    }
                }
            }
        }

        // POS Menu Grid
        item {
            Text("POS MENU ITEMS", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }

        if (items.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth().height(150.dp), contentAlignment = Alignment.Center) {
                    Text("No Menu Items configured. Add menu items above.", color = Color.Gray)
                }
            }
        } else {
            // Display items in a beautiful list with cart buttons and recipe buttons
            items(items) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(item.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                                Spacer(modifier = Modifier.width(8.dp))
                                Badge(containerColor = MaterialTheme.colorScheme.secondaryContainer) {
                                    Text(item.category, fontSize = 9.sp)
                                }
                            }
                            Text(item.description, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Rs. ${String.format("%.2f", item.sellingPrice)}", fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (viewModel.hasPermission("manage_recipes")) {
                                IconButton(onClick = {
                                    selectedMenuItemIdForRecipe = item.id
                                    showRecipeBuilder = true
                                }) {
                                    Icon(Icons.Default.MenuBook, contentDescription = "Edit Recipe", tint = MaterialTheme.colorScheme.secondary)
                                }
                            }

                            if (viewModel.hasPermission("record_sale")) {
                                var qtyInputText by remember { mutableStateOf("1") }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    modifier = Modifier.padding(start = 4.dp)
                                ) {
                                    OutlinedTextField(
                                        value = qtyInputText,
                                        onValueChange = { newValue ->
                                            qtyInputText = newValue.filter { it.isDigit() }
                                        },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        modifier = Modifier
                                            .width(70.dp)
                                            .height(48.dp)
                                            .testTag("qty_input_${item.id}"),
                                        textStyle = MaterialTheme.typography.bodyMedium.copy(textAlign = TextAlign.Center),
                                        placeholder = { Text("1", fontSize = 12.sp) }
                                    )
                                    IconButton(
                                        onClick = {
                                            val qty = qtyInputText.toIntOrNull() ?: 1
                                            if (qty > 0) {
                                                viewModel.addToCartWithQty(item.id, qty)
                                                qtyInputText = "1"
                                            }
                                        },
                                        modifier = Modifier.testTag("add_to_cart_${item.id}")
                                    ) {
                                        Icon(Icons.Default.AddShoppingCart, contentDescription = "Add to Cart", tint = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Checkout Confirmation Dialog
    if (showCheckoutDialog) {
        AlertDialog(
            onDismissRequest = { showCheckoutDialog = false },
            title = { Text("Complete Order") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("This sale will automatically calculate recipes, deduct the appropriate quantity from inventory, and trigger warnings if ingredients are low.")
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Checkout Notes / Table Number") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.recordSalesCheckout(notes)
                        notes = ""
                        showCheckoutDialog = false
                    },
                    modifier = Modifier.testTag("confirm_checkout_button")
                ) {
                    Text("Confirm Checkout")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCheckoutDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

// ==========================================
// 3. INVENTORY TAB
// ==========================================
@Composable
fun InventoryTab(viewModel: RestaurantViewModel) {
    val ingredientsList by viewModel.ingredients.collectAsStateWithLifecycle()
    val suppliersList by viewModel.suppliers.collectAsStateWithLifecycle()
    val purchasesList by viewModel.purchases.collectAsStateWithLifecycle()
    val transactionsList by viewModel.transactions.collectAsStateWithLifecycle()

    var showAddIngForm by remember { mutableStateOf(false) }
    var showPurchaseForm by remember { mutableStateOf(false) }

    // Add ingredient state
    var ingName by remember { mutableStateOf("") }
    var ingMinStock by remember { mutableStateOf("") }
    var ingMaxStock by remember { mutableStateOf("") }
    var ingUnit by remember { mutableStateOf("kg") }
    var ingSupplierId by remember { mutableStateOf<Int?>(null) }

    // Purchase form state
    var purIngId by remember { mutableStateOf<Int?>(null) }
    var purSupId by remember { mutableStateOf<Int?>(null) }
    var purQty by remember { mutableStateOf("") }
    var purPrice by remember { mutableStateOf("") }
    var purInvoice by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text("Inventory & Purchasing", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("Real-time stocks and purchase history", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val hasInv = viewModel.hasPermission("manage_inventory")
                    val hasPur = viewModel.hasPermission("record_purchase")

                    if (hasInv) {
                        Button(
                            onClick = { showAddIngForm = !showAddIngForm },
                            modifier = Modifier.weight(1f).testTag("add_ingredient_button")
                        ) {
                            Icon(if (showAddIngForm) Icons.Default.Close else Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Ingredient")
                        }
                    }
                    if (hasPur) {
                        Button(
                            onClick = { showPurchaseForm = !showPurchaseForm },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                            modifier = Modifier.weight(1f).testTag("add_purchase_button")
                        ) {
                            Icon(if (showPurchaseForm) Icons.Default.Close else Icons.Default.ShoppingCart, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Purchase")
                        }
                    }
                }
            }
        }

        // Add Ingredient Form
        if (showAddIngForm) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Register Ingredient", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        OutlinedTextField(
                            value = ingName,
                            onValueChange = { ingName = it },
                            label = { Text("Ingredient Name") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedTextField(
                                value = ingMinStock,
                                onValueChange = { ingMinStock = it },
                                label = { Text("Min Stock") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = ingMaxStock,
                                onValueChange = { ingMaxStock = it },
                                label = { Text("Max Stock") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            // Unit Select
                            var expandedUnit by remember { mutableStateOf(false) }
                            Box(modifier = Modifier.weight(1f).padding(top = 8.dp)) {
                                Button(onClick = { expandedUnit = true }, modifier = Modifier.fillMaxWidth()) {
                                    Text("Unit: $ingUnit")
                                }
                                DropdownMenu(expanded = expandedUnit, onDismissRequest = { expandedUnit = false }) {
                                    listOf("kg", "L", "pcs", "g", "ml").forEach { unit ->
                                        DropdownMenuItem(text = { Text(unit) }, onClick = {
                                            ingUnit = unit
                                            expandedUnit = false
                                        })
                                    }
                                }
                            }

                            // Supplier Select
                            var expandedSup by remember { mutableStateOf(false) }
                            val currentSup = suppliersList.find { it.id == ingSupplierId }
                            Box(modifier = Modifier.weight(1f).padding(top = 8.dp)) {
                                Button(onClick = { expandedSup = true }, modifier = Modifier.fillMaxWidth()) {
                                    Text(currentSup?.name ?: "Supplier")
                                }
                                DropdownMenu(expanded = expandedSup, onDismissRequest = { expandedSup = false }) {
                                    suppliersList.forEach { sup ->
                                        DropdownMenuItem(text = { Text(sup.name) }, onClick = {
                                            ingSupplierId = sup.id
                                            expandedSup = false
                                        })
                                    }
                                }
                            }
                        }

                        Button(
                            onClick = {
                                val min = ingMinStock.toDoubleOrNull() ?: 0.0
                                val max = ingMaxStock.toDoubleOrNull() ?: 0.0
                                if (ingName.isNotEmpty()) {
                                    viewModel.addIngredient(ingName, min, max, ingUnit, ingSupplierId)
                                    ingName = ""
                                    ingMinStock = ""
                                    ingMaxStock = ""
                                    ingSupplierId = null
                                    showAddIngForm = false
                                }
                            },
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Text("Save Ingredient")
                        }
                    }
                }
            }
        }

        // Record Purchase Form
        if (showPurchaseForm) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Record Supplier Purchase", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        
                        // Select Ingredient
                        var expIng by remember { mutableStateOf(false) }
                        val selectedIng = ingredientsList.find { it.id == purIngId }
                        Box(modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(onClick = { expIng = true }, modifier = Modifier.fillMaxWidth()) {
                                Text(selectedIng?.name ?: "Select Ingredient")
                            }
                            DropdownMenu(expanded = expIng, onDismissRequest = { expIng = false }) {
                                ingredientsList.forEach { ing ->
                                    DropdownMenuItem(text = { Text(ing.name) }, onClick = {
                                        purIngId = ing.id
                                        expIng = false
                                    })
                                }
                            }
                        }

                        // Select Supplier
                        var expSup by remember { mutableStateOf(false) }
                        val selectedSup = suppliersList.find { it.id == purSupId }
                        Box(modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(onClick = { expSup = true }, modifier = Modifier.fillMaxWidth()) {
                                Text(selectedSup?.name ?: "Select Supplier")
                            }
                            DropdownMenu(expanded = expSup, onDismissRequest = { expSup = false }) {
                                suppliersList.forEach { sup ->
                                    DropdownMenuItem(text = { Text(sup.name) }, onClick = {
                                        purSupId = sup.id
                                        expSup = false
                                    })
                                }
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedTextField(
                                value = purQty,
                                onValueChange = { purQty = it },
                                label = { Text("Quantity") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = purPrice,
                                onValueChange = { purPrice = it },
                                label = { Text("Price per unit (Rs.)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        OutlinedTextField(
                            value = purInvoice,
                            onValueChange = { purInvoice = it },
                            label = { Text("Invoice Number") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Button(
                            onClick = {
                                val qty = purQty.toDoubleOrNull() ?: 0.0
                                val price = purPrice.toDoubleOrNull() ?: 0.0
                                if (purIngId != null && purSupId != null && qty > 0.0 && price > 0.0 && purInvoice.isNotEmpty()) {
                                    viewModel.recordPurchaseEntry(purIngId!!, purSupId!!, qty, price, purInvoice)
                                    purQty = ""
                                    purPrice = ""
                                    purInvoice = ""
                                    purIngId = null
                                    purSupId = null
                                    showPurchaseForm = false
                                }
                            },
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Text("Confirm Purchase")
                        }
                    }
                }
            }
        }

        // Ingredient Analytics Visualizers (Charts)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Stock Usage vs Purchases Analytics", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))

                    // Line chart showing purchases over past transactions
                    val salesUsage = transactionsList.filter { it.type == "Sale" }.map { Math.abs(it.quantity).toFloat() }.take(6)
                    val purEntries = transactionsList.filter { it.type == "Purchase" }.map { it.quantity.toFloat() }.take(6)

                    if (salesUsage.isNotEmpty() || purEntries.isNotEmpty()) {
                        CustomLineChart(
                            salesData = salesUsage,
                            purchasesData = purEntries,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxWidth()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(12.dp).background(Color(0xFFE91E63)))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Consumed", style = MaterialTheme.typography.bodySmall)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(12.dp).background(Color(0xFF4CAF50)))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Purchased", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    } else {
                        Text("Not enough historical metrics to render charts. Record some POS checkouts first.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        // Inventory Stock levels Table List
        item {
            Text("INGREDIENTS STOCK LEVELS", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }

        if (ingredientsList.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth().height(150.dp), contentAlignment = Alignment.Center) {
                    Text("No ingredients configured. Seed or insert one above.", color = Color.Gray)
                }
            }
        } else {
            items(ingredientsList) { item ->
                val ratio = (item.currentStock / item.maxStock).toFloat().coerceIn(0f, 1f)
                val isLow = item.currentStock < item.minStock
                
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(item.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    if (isLow) {
                                        Badge(containerColor = MaterialTheme.colorScheme.errorContainer) {
                                            Text("Low Stock", color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 9.sp)
                                        }
                                    } else {
                                        Badge(containerColor = Color(0xFFE8F5E9)) {
                                            Text("Healthy", color = Color(0xFF2E7D32), fontSize = 9.sp)
                                        }
                                    }
                                }
                                Text("Avg Cost: Rs. ${String.format("%.2f", item.averageCost)} | Expiry: ${item.expiryDate ?: "N/A"}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "${String.format("%.1f", item.currentStock)} ${item.unit}",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 16.sp,
                                    color = if (isLow) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "Book: Rs. ${String.format("%.2f", item.inventoryValue)}",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        // Progress bar indicator
                        LinearProgressIndicator(
                            progress = { ratio },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = if (isLow) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp)
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// 4. SUPPLIERS & EXPENSES TAB
// ==========================================
@Composable
fun SuppliersExpensesTab(viewModel: RestaurantViewModel) {
    val suppliersList by viewModel.suppliers.collectAsStateWithLifecycle()
    val expensesList by viewModel.expenses.collectAsStateWithLifecycle()

    var showAddSupForm by remember { mutableStateOf(false) }
    var showAddExpForm by remember { mutableStateOf(false) }

    // Supplier form state
    var supName by remember { mutableStateOf("") }
    var supPhone by remember { mutableStateOf("") }
    var supEmail by remember { mutableStateOf("") }
    var supAddress by remember { mutableStateOf("") }

    // Expense form state
    var expCategory by remember { mutableStateOf("Salary") }
    var expAmount by remember { mutableStateOf("") }
    var expNotes by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text("Suppliers & Expenses", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("Manage vendors and track utilities, rent, etc.", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val hasSup = viewModel.hasPermission("manage_suppliers")
                    val hasExp = viewModel.hasPermission("manage_expenses")

                    if (hasSup) {
                        Button(
                            onClick = { showAddSupForm = !showAddSupForm },
                            modifier = Modifier.weight(1f).testTag("add_supplier_button")
                        ) {
                            Icon(if (showAddSupForm) Icons.Default.Close else Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Supplier")
                        }
                    }
                    if (hasExp) {
                        Button(
                            onClick = { showAddExpForm = !showAddExpForm },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                            modifier = Modifier.weight(1f).testTag("add_expense_button")
                        ) {
                            Icon(if (showAddExpForm) Icons.Default.Close else Icons.Default.AttachMoney, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Expense")
                        }
                    }
                }
            }
        }

        // Add Supplier Form
        if (showAddSupForm) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Add Supplier Profile", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        OutlinedTextField(
                            value = supName,
                            onValueChange = { supName = it },
                            label = { Text("Vendor / Supplier Name") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedTextField(
                                value = supPhone,
                                onValueChange = { supPhone = it },
                                label = { Text("Phone") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = supEmail,
                                onValueChange = { supEmail = it },
                                label = { Text("Email Address") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                                modifier = Modifier.weight(1f)
                            )
                        }
                        OutlinedTextField(
                            value = supAddress,
                            onValueChange = { supAddress = it },
                            label = { Text("Address / Location") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(
                            onClick = {
                                if (supName.isNotEmpty()) {
                                    viewModel.addSupplier(supName, supPhone, supEmail, supAddress)
                                    supName = ""
                                    supPhone = ""
                                    supEmail = ""
                                    supAddress = ""
                                    showAddSupForm = false
                                }
                            },
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Text("Save Supplier")
                        }
                    }
                }
            }
        }

        // Add Expense Form
        if (showAddExpForm) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Record Operational Expense", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        
                        // Category Select
                        var expCategoryDrop by remember { mutableStateOf(false) }
                        Box(modifier = Modifier.fillMaxWidth()) {
                            Button(onClick = { expCategoryDrop = true }, modifier = Modifier.fillMaxWidth()) {
                                Text("Category: $expCategory")
                            }
                            DropdownMenu(expanded = expCategoryDrop, onDismissRequest = { expCategoryDrop = false }) {
                                listOf("Salary", "Rent", "Utilities", "Maintenance", "Fuel", "Marketing", "Packaging", "Cleaning", "Miscellaneous").forEach { cat ->
                                    DropdownMenuItem(text = { Text(cat) }, onClick = {
                                        expCategory = cat
                                        expCategoryDrop = false
                                    })
                                }
                            }
                        }

                        OutlinedTextField(
                            value = expAmount,
                            onValueChange = { expAmount = it },
                            label = { Text("Expense Amount (Rs.)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = expNotes,
                            onValueChange = { expNotes = it },
                            label = { Text("Notes / Description") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Button(
                            onClick = {
                                val amt = expAmount.toDoubleOrNull() ?: 0.0
                                if (amt > 0.0) {
                                    viewModel.recordExpenseEntry(expCategory, amt, expNotes)
                                    expAmount = ""
                                    expNotes = ""
                                    showAddExpForm = false
                                }
                            },
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Text("Record Expense")
                        }
                    }
                }
            }
        }

        // Expenses breakdown Custom Donut Chart
        if (expensesList.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Expense Categories Distribution", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Start))
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        val expGroup = expensesList.groupBy { it.category }.map { entry -> entry.key to entry.value.sumOf { it.amount }.toFloat() }
                        CustomDonutChart(
                            data = expGroup,
                            modifier = Modifier.size(150.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        // Render Legend
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            modifier = Modifier.height(80.dp).fillMaxWidth()
                        ) {
                            items(expGroup) { (cat, amt) ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(4.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(12.dp)
                                            .background(getColorForCategory(cat))
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "$cat: Rs. ${String.format("%.1f", amt)}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Suppliers profiles List
        item {
            Text("REGISTERED SUPPLIERS", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }

        if (suppliersList.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) {
                    Text("No registered suppliers. Add one above.", color = Color.Gray)
                }
            }
        } else {
            items(suppliersList) { vendor ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(vendor.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                            Icon(Icons.Default.ContactMail, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        }
                        Text("Phone: ${vendor.phone} | Email: ${vendor.email}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        Text("Address: ${vendor.address}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

// Helper to assign colors to expense categories
fun getColorForCategory(cat: String): Color {
    return when (cat) {
        "Salary" -> Color(0xFF2196F3)
        "Rent" -> Color(0xFFE91E63)
        "Utilities" -> Color(0xFFFFEB3B)
        "Maintenance" -> Color(0xFF9C27B0)
        "Fuel" -> Color(0xFF4CAF50)
        "Marketing" -> Color(0xFF00BCD4)
        "Packaging" -> Color(0xFFFF9800)
        "Cleaning" -> Color(0xFF795548)
        else -> Color(0xFF607D8B)
    }
}

// ==========================================
// 5. AI INSIGHTS TAB (GEMINI API)
// ==========================================
@Composable
fun AiInsightsTab(viewModel: RestaurantViewModel) {
    val aiState by viewModel.aiInsights.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text("Gemini AI Copilot", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Analyze operations, predict inventory needs, detect waste", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Audit Restaurant Health",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            "Feeds live transaction records, current low stock logs, and expense volumes directly into Gemini.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { viewModel.fetchAiInsights() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.testTag("run_ai_audit_button")
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Audit")
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        "Operational Intelligence Output",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall
                    )
                    Divider()

                    when (val state = aiState) {
                        is AiState.Idle -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        Icons.Default.Psychology,
                                        contentDescription = null,
                                        modifier = Modifier.size(48.dp),
                                        tint = Color.Gray
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        "Copilot is resting. Click 'Audit' to query Gemini.",
                                        color = Color.Gray,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }

                        is AiState.Loading -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    CircularProgressIndicator()
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text("Gemini is crunching your restaurant logs...", style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }

                        is AiState.Success -> {
                            Text(
                                text = state.response,
                                style = MaterialTheme.typography.bodyMedium,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.testTag("ai_insights_output_text")
                            )
                        }

                        is AiState.Error -> {
                            Text(
                                text = "Error fetching analysis: ${state.error}",
                                color = MaterialTheme.colorScheme.error,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 6. REPORTS TAB
// ==========================================
@Composable
fun ReportsTab(viewModel: RestaurantViewModel) {
    val context = LocalContext.current
    var reportType by remember { mutableStateOf("sales") }
    var reportOutput by remember { mutableStateOf("") }
    val employeesList by viewModel.employees.collectAsStateWithLifecycle()

    var showAddEmployeeForm by remember { mutableStateOf(false) }
    var empName by remember { mutableStateOf("") }
    var empRole by remember { mutableStateOf("Cashier") }
    var empEmail by remember { mutableStateOf("") }
    var empPhone by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text("Operational Reporting", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Compile lists and export tables directly to CSV", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
            }
        }

        // Selection buttons
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("sales", "expenses", "inventory").forEach { type ->
                    val isSelected = reportType == type
                    Button(
                        onClick = { reportType = type },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondaryContainer,
                            contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSecondaryContainer
                        ),
                        modifier = Modifier.weight(1f).testTag("select_report_$type")
                    ) {
                        Text(type.uppercase(Locale.US), fontSize = 11.sp)
                    }
                }
            }
        }

        // Report actions
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        reportOutput = viewModel.generateReportText(reportType)
                    },
                    modifier = Modifier.weight(1.2f).testTag("generate_report_button")
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Generate On Screen")
                }

                Button(
                    onClick = {
                        val reportText = viewModel.generateReportText(reportType)
                        shareReportCsv(context, reportType, reportText)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF388E3C)),
                    modifier = Modifier.weight(1f).testTag("export_csv_button")
                ) {
                    Icon(Icons.Default.Share, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Export CSV")
                }
            }
        }

        // Report on-screen display card
        if (reportOutput.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("On Screen Output", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            TextButton(onClick = { reportOutput = "" }) {
                                Text("Clear", color = MaterialTheme.colorScheme.error)
                            }
                        }
                        Divider(modifier = Modifier.padding(vertical = 8.dp))
                        Text(
                            text = reportOutput,
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.testTag("report_output_viewer")
                        )
                    }
                }
            }
        }

        // Add Employee Form (Collapsible)
        if (showAddEmployeeForm && viewModel.hasPermission("manage_employees")) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("add_employee_form"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("Add New Employee", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        
                        OutlinedTextField(
                            value = empName,
                            onValueChange = { empName = it },
                            label = { Text("Employee Name") },
                            modifier = Modifier.fillMaxWidth().testTag("emp_name_input")
                        )

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = empEmail,
                                onValueChange = { empEmail = it },
                                label = { Text("Email Address") },
                                modifier = Modifier.weight(1f).testTag("emp_email_input")
                            )
                            OutlinedTextField(
                                value = empPhone,
                                onValueChange = { empPhone = it },
                                label = { Text("Phone Number") },
                                modifier = Modifier.weight(1f).testTag("emp_phone_input")
                            )
                        }

                        // Role Selector
                        var expandedRole by remember { mutableStateOf(false) }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Select Role: ", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                            Box {
                                Button(
                                    onClick = { expandedRole = true },
                                    modifier = Modifier.testTag("emp_role_dropdown_btn")
                                ) {
                                    Text(empRole)
                                }
                                DropdownMenu(
                                    expanded = expandedRole,
                                    onDismissRequest = { expandedRole = false }
                                ) {
                                    listOf("Owner", "Admin", "Manager", "Cashier", "Kitchen Staff").forEach { role ->
                                        DropdownMenuItem(
                                            text = { Text(role) },
                                            onClick = {
                                                empRole = role
                                                expandedRole = false
                                            },
                                            modifier = Modifier.testTag("role_item_$role")
                                        )
                                    }
                                }
                            }
                        }

                        Button(
                            onClick = {
                                if (empName.isNotEmpty() && empEmail.isNotEmpty()) {
                                    viewModel.addEmployee(empName, empRole, empEmail, empPhone)
                                    empName = ""
                                    empEmail = ""
                                    empPhone = ""
                                    empRole = "Cashier"
                                    showAddEmployeeForm = false
                                }
                            },
                            modifier = Modifier.align(Alignment.End).testTag("save_employee_button")
                        ) {
                            Text("Save Employee")
                        }
                    }
                }
            }
        }

        // Employee roster list
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "STAFF ROSTER & CREDENTIAL ROLES",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
                if (viewModel.hasPermission("manage_employees")) {
                    Button(
                        onClick = { showAddEmployeeForm = !showAddEmployeeForm },
                        modifier = Modifier.testTag("add_employee_button"),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Icon(if (showAddEmployeeForm) Icons.Default.Close else Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (showAddEmployeeForm) "Hide" else "Add Staff", fontSize = 12.sp)
                    }
                }
            }
        }

        items(employeesList) { staff ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(staff.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                        Text("Email: ${staff.email} | Contact: ${staff.phone}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.tertiaryContainer)
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = staff.role,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                        }
                        if (viewModel.hasPermission("manage_employees")) {
                            IconButton(
                                onClick = { viewModel.deleteEmployee(staff) },
                                modifier = Modifier.size(24.dp).testTag("delete_employee_${staff.id}")
                            ) {
                                Icon(
                                    Icons.Default.Delete,
                                    contentDescription = "Delete Employee",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// Function to share compiled reports as a CSV download file inside Android
fun shareReportCsv(context: Context, type: String, text: String) {
    try {
        val fileName = "biteflow_report_${type}_${SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())}.csv"
        val file = File(context.cacheDir, fileName)
        val writer = FileWriter(file)
        
        // Convert the report text lines to CSV values
        text.lines().forEach { line ->
            val cleanLine = line.replace("|", ",").trim()
            if (cleanLine.isNotEmpty() && !cleanLine.startsWith("===") && !cleanLine.startsWith("---")) {
                writer.append(cleanLine).append("\n")
            }
        }
        writer.flush()
        writer.close()

        val uri = androidx.core.content.FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            this.type = "text/csv"
            putExtra(Intent.EXTRA_SUBJECT, "BiteFlow ERP Generated ${type.uppercase(Locale.US)} Report")
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share ERP CSV Report"))
    } catch (e: Exception) {
        // Fallback share as simple plain text if FileProvider is not set up
        val intent = Intent(Intent.ACTION_SEND).apply {
            this.type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "BiteFlow ERP Generated Report")
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(Intent.createChooser(intent, "Share ERP Text Report"))
    }
}

// ==========================================
// CUSTOM CANVAS DRAWING CHARTS
// ==========================================

@Composable
fun CustomBarChart(
    data: List<Pair<String, Float>>,
    modifier: Modifier = Modifier
) {
    val primaryColor = MaterialTheme.colorScheme.primary
    val secondaryColor = MaterialTheme.colorScheme.secondary
    val labelColor = MaterialTheme.colorScheme.onSurfaceVariant

    Canvas(modifier = modifier) {
        val maxVal = data.maxOfOrNull { it.second } ?: 1f
        val paddingLeft = 40.dp.toPx()
        val paddingBottom = 40.dp.toPx()
        val graphWidth = size.width - paddingLeft
        val graphHeight = size.height - paddingBottom

        // Draw Axes
        drawLine(
            color = labelColor.copy(alpha = 0.3f),
            start = Offset(paddingLeft, 0f),
            end = Offset(paddingLeft, graphHeight),
            strokeWidth = 2.dp.toPx()
        )
        drawLine(
            color = labelColor.copy(alpha = 0.3f),
            start = Offset(paddingLeft, graphHeight),
            end = Offset(size.width, graphHeight),
            strokeWidth = 2.dp.toPx()
        )

        val barCount = data.size
        val barWidth = (graphWidth / barCount) * 0.5f
        val gap = (graphWidth / barCount) * 0.5f

        data.forEachIndexed { idx, (label, valFloat) ->
            val ratio = if (maxVal > 0f) valFloat / maxVal else 0f
            val barHeight = graphHeight * ratio
            val xOffset = paddingLeft + gap * 0.5f + idx * (barWidth + gap)
            val yOffset = graphHeight - barHeight

            // Draw individual bar
            drawRect(
                color = if (idx % 2 == 0) primaryColor else secondaryColor,
                topLeft = Offset(xOffset, yOffset),
                size = Size(barWidth, barHeight)
            )
        }
    }
}

@Composable
fun CustomLineChart(
    salesData: List<Float>,
    purchasesData: List<Float>,
    modifier: Modifier = Modifier
) {
    val colorSales = Color(0xFFE91E63)
    val colorPurchases = Color(0xFF4CAF50)

    Canvas(modifier = modifier) {
        val paddingLeft = 30.dp.toPx()
        val paddingBottom = 30.dp.toPx()
        val graphWidth = size.width - paddingLeft
        val graphHeight = size.height - paddingBottom

        // Plot sales path
        if (salesData.isNotEmpty()) {
            val maxVal = salesData.maxOrNull() ?: 1f
            val stepX = graphWidth / (salesData.size - 1).coerceAtLeast(1)
            val points = salesData.mapIndexed { idx, valFloat ->
                val ratio = if (maxVal > 0f) valFloat / maxVal else 0f
                Offset(paddingLeft + idx * stepX, graphHeight - (graphHeight * ratio))
            }
            for (i in 0 until points.size - 1) {
                drawLine(
                    color = colorSales,
                    start = points[i],
                    end = points[i + 1],
                    strokeWidth = 3.dp.toPx()
                )
            }
        }

        // Plot purchases path
        if (purchasesData.isNotEmpty()) {
            val maxVal = purchasesData.maxOrNull() ?: 1f
            val stepX = graphWidth / (purchasesData.size - 1).coerceAtLeast(1)
            val points = purchasesData.mapIndexed { idx, valFloat ->
                val ratio = if (maxVal > 0f) valFloat / maxVal else 0f
                Offset(paddingLeft + idx * stepX, graphHeight - (graphHeight * ratio))
            }
            for (i in 0 until points.size - 1) {
                drawLine(
                    color = colorPurchases,
                    start = points[i],
                    end = points[i + 1],
                    strokeWidth = 3.dp.toPx()
                )
            }
        }
    }
}

@Composable
fun CustomDonutChart(
    data: List<Pair<String, Float>>,
    modifier: Modifier = Modifier
) {
    val total = data.sumOf { it.second.toDouble() }.toFloat()

    Canvas(modifier = modifier) {
        var startAngle = 0f
        data.forEachIndexed { idx, (cat, value) ->
            val sweepAngle = if (total > 0f) (value / total) * 360f else 360f / data.size
            drawArc(
                color = getColorForCategory(cat),
                startAngle = startAngle,
                sweepAngle = sweepAngle,
                useCenter = false,
                style = Stroke(width = 30.dp.toPx())
            )
            startAngle += sweepAngle
        }
    }
}
